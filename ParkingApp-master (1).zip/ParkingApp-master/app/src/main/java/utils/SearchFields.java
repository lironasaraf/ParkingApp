package utils;

public enum SearchFields {

    CITY,
    STREET,
    DATEFROM,
    DATETO,
    MAXPRICSE,
    EMAIL
}
