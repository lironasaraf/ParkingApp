package Intrfaces;

public interface PasswordReseter {
    void onResetResults(boolean result);
}
