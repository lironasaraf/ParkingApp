package Intrfaces;

public interface UserAdder {
    void userAdded(boolean isSuccessful);
}
