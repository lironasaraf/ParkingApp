package Intrfaces;

import java.util.List;

import utils.User;

public interface UsersGetter {
    void gotUsers(List<User> users);
}
