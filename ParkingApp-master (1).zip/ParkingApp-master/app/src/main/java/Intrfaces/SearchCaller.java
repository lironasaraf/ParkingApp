package Intrfaces;

import android.net.Uri;

import utils.Post;

import java.util.ArrayList;

public interface SearchCaller {

    void gotSearchResults(ArrayList<Post> posts);

}
