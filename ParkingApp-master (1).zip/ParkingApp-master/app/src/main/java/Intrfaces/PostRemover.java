package Intrfaces;

public interface PostRemover {
    void postRemoved(boolean isSuccessful);
}
