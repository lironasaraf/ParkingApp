package Intrfaces;

public interface PostUploader {

    void uploaded(boolean isSuccessful);
}
