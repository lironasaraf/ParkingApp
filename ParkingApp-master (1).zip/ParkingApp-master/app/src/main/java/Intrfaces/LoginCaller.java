package Intrfaces;

import utils.User;

public interface LoginCaller {
    void finishLogin(User user, int type);
}
