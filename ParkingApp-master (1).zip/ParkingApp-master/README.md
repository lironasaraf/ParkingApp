# ParkingApp
<img width="1413" alt="Screen Shot 2021-12-12 at 14 41 14" src="https://user-images.githubusercontent.com/73247185/145712668-161a1af2-e500-42b5-a80b-d40309a3ad9c.png">
<img width="1413" alt="Screen Shot 2021-12-12 at 14 29 51" src="https://user-images.githubusercontent.com/73247185/145712332-d89b4cb3-ebf8-4223-9101-193314f58a86.png">
<img width="1413" alt="Screen Shot 2021-12-12 at 14 30 21" src="https://user-images.githubusercontent.com/73247185/145712373-7e519ffa-8e5c-4e81-bf0a-5f856ca0e212.png">
<img width="1413" alt="Screen Shot 2021-12-12 at 14 30 30" src="https://user-images.githubusercontent.com/73247185/145712390-15ce58e2-53d9-4dea-93e7-451faab8c912.png">
<img width="1413" alt="Screen Shot 2021-12-12 at 14 30 38" src="https://user-images.githubusercontent.com/73247185/145712396-bd301bb1-3aa0-4c9b-8c9a-a6c55d92b62f.png">
<img width="1413" alt="Screen Shot 2021-12-12 at 14 30 45" src="https://user-images.githubusercontent.com/73247185/145712431-0e518270-6b36-401b-8af7-58aab1ceb4cc.png">
<img width="1413" alt="Screen Shot 2021-12-12 at 14 30 56" src="https://user-images.githubusercontent.com/73247185/145712446-6f9ab9d0-3a11-4cab-a5f9-87fd85f031b9.png">
<img width="1413" alt="Screen Shot 2021-12-12 at 14 31 15" src="https://user-images.githubusercontent.com/73247185/145712466-7e602f36-3654-42d4-b0e0-dac8a2ee2632.png">
